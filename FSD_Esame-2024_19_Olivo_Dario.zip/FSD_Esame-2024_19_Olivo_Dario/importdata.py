import pandas as pd
import requests
from io import StringIO
import sqlite3

# URL dei dataset
sopravvivenza_url = 'https://raw.githubusercontent.com/DarioOlivo/fintech2023/main/Tasso-sopravvivenza-imprese-alta-intensita-di-conoscenza-per-regione.csv'
incidenzaSpesa_url = 'https://raw.githubusercontent.com/DarioOlivo/fintech2023/main/Incidenza-spesa-imprese-in-ricerca-e-sviluppo-per-regione.csv'
partecipazione_url = 'https://raw.githubusercontent.com/DarioOlivo/fintech2023/main/Partecipazione-della-popolazione-al-mercato-del-lavoro-per-regione.csv'

# Funzione per importare e processare i dati
def import_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        csv_content = StringIO(response.text)
        df = pd.read_csv(csv_content, sep=';')
        df.columns = [col.replace('�', 'à') for col in df.columns]
        return df
    else:
        print(f"Errore nell'importazione dei dati da {url}")
        return None

df_sopravvivenza = import_data(sopravvivenza_url)
df_incidenza = import_data(incidenzaSpesa_url)
df_partecipazione = import_data(partecipazione_url)

#print(df_sopravvivenza)
#print(df_incidenza)
#print(df_partecipazione)

# Verifico la presenza di valori nulli
print("Valori nulli in df_sopravvivenza prima della sostituzione:")
print(df_sopravvivenza.isnull().sum())
print("Valori nulli in df_incidenza prima della sostituzione:")
print(df_incidenza.isnull().sum())
print("Valori nulli in df_partecipazione prima della sostituzione:")
print(df_partecipazione.isnull().sum())
#non sono presenti valori nulli

# Modifica i nomi delle colonne in base ai dati reali
df_incidenza = df_incidenza.rename(columns={
    'Percentuale spesa imprese in ricerca e sviluppo': 'spesa_imprese'
})
#etŕ
df_partecipazione = df_partecipazione.rename(columns={
    'Percentuale forze di lavoro in etŕ 15-64 anni': 'forza_lavoro'
})
df_sopravvivenza = df_sopravvivenza.rename(columns={
    'Percentuale sopravvivenza imprese alta conoscenza ': 'sopravvivenza_imprese'
})#lacio lo spazio prima dell'apice finale di conoscenza perchè se no non avviene cambio nome colonna


# Connessione al database
conn = sqlite3.connect('imprese.db')
cursor = conn.cursor()

# Inserimento dei dati nelle tabelle
for _, row in df_sopravvivenza.iterrows():
    regione_id = cursor.execute("SELECT id FROM regioni WHERE nome = ?", (row['Regione'],)).fetchone()[0]
    cursor.execute('INSERT INTO sopravvivenza_imprese (regione_id, anno, sopravvivenza_imprese) VALUES (?, ?, ?)',
                   (regione_id, row['Anno'], row['sopravvivenza_imprese']))

for _, row in df_incidenza.iterrows():
    regione_id = cursor.execute("SELECT id FROM regioni WHERE nome = ?", (row['Regione'],)).fetchone()[0]
    cursor.execute('INSERT INTO spesa_imprese (regione_id, anno, spesa_imprese) VALUES (?, ?, ?)',
                   (regione_id, row['Anno'], row['spesa_imprese']))

for _, row in df_partecipazione.iterrows():
    regione_id = cursor.execute("SELECT id FROM regioni WHERE nome = ?", (row['Regione'],)).fetchone()[0]
    cursor.execute('INSERT INTO forza_lavoro (regione_id, anno, forza_lavoro) VALUES (?, ?, ?)',
                   (regione_id, row['Anno'], row['forza_lavoro']))

conn.commit()
conn.close()
