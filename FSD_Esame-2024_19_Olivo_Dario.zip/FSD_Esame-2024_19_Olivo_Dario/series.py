import sqlite3
import pandas as pd

def query_db(query: str, params: tuple = ()):
    conn = sqlite3.connect('imprese.db')
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df

# Connessione al database
conn = sqlite3.connect('imprese.db')
cursor = conn.cursor()

# Creazione delle tabelle per le serie calcolate
cursor.execute('''
CREATE TABLE IF NOT EXISTS partecipazione_mercato_lavoro_aree (
    anno INTEGER,
    area_geografica TEXT,
    partecipazione_mercato_lavoro FLOAT,
    PRIMARY KEY (anno, area_geografica)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS partecipazione_mercato_lavoro_nazionale (
    anno INTEGER,
    partecipazione_mercato_lavoro FLOAT,
    PRIMARY KEY (anno)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS media_incidenza_spesa_ricerca_sviluppo_aree (
    anno INTEGER,
    area_geografica TEXT,
    media_incidenza_spesa_ricerca_sviluppo FLOAT,
    PRIMARY KEY (anno, area_geografica)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS media_tasso_sopravvivenza_imprese_nazionale (
    anno INTEGER,
    media_tasso_sopravvivenza FLOAT,
    PRIMARY KEY (anno)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS media_tasso_sopravvivenza_imprese_aree (
    anno INTEGER,
    area_geografica TEXT,
    media_tasso_sopravvivenza FLOAT,
    PRIMARY KEY (anno, area_geografica)
)
''')

# Query per ottenere i dati necessari
query_spesa = "SELECT * FROM spesa_imprese"
query_forza = "SELECT * FROM forza_lavoro"
query_sopravvivenza = "SELECT * FROM sopravvivenza_imprese"
query_regioni = "SELECT * FROM regioni"

query_spesa = "SELECT * FROM spesa_imprese"
query_forza = "SELECT * FROM forza_lavoro"
query_sopravvivenza = "SELECT * FROM sopravvivenza_imprese"
query_regioni = "SELECT * FROM regioni"

df_incidenza = query_db(query_spesa)
df_partecipazione = query_db(query_forza)
df_sopravvivenza = query_db(query_sopravvivenza)
df_regioni = query_db(query_regioni)

# Unione dei dati con le regioni per ottenere le aree geografiche
df_incidenza = pd.merge(df_incidenza, df_regioni, left_on='regione_id', right_on='id')
df_partecipazione = pd.merge(df_partecipazione, df_regioni, left_on='regione_id', right_on='id')
df_sopravvivenza = pd.merge(df_sopravvivenza, df_regioni, left_on='regione_id', right_on='id')


#1. Partecipazione popolazione al mercato del lavoro delle 5 Aree Nord-ovest, Nord-est, Centro, Sud, Isole
partecipazione_mercato_lavoro_aree = df_partecipazione.groupby(['anno', 'area_geografica'])['forza_lavoro'].sum().reset_index()

#2. Partecipazione popolazione al mercato del lavoro NAZIONALE
partecipazione_mercato_lavoro_nazionale = df_partecipazione.groupby(['anno'])['forza_lavoro'].sum().reset_index()

#3. Media incidenza spesa imprese in ricerca sviluppo delle 5 Aree Nord-ovest, Nord-est, Centro, Sud, Isole
media_incidenza_spesa_ricerca_sviluppo_aree = df_incidenza.groupby(['anno', 'area_geografica'])['spesa_imprese'].mean().reset_index()

#4 Media tasso di sopravvivenza imprese alto tasso conoscenza NAZIONALE
media_tasso_sopravvivenza_imprese_nazionale = df_sopravvivenza.groupby(['anno'])['sopravvivenza_imprese'].mean().reset_index()

#5. Media tasso di sopravvivenza imprese alto tasso conoscenza delle 5 Aree Nord-ovest, Nord-est, Centro, Sud, Isole
media_tasso_sopravvivenza_imprese_aree = df_sopravvivenza.groupby(['anno', 'area_geografica'])['sopravvivenza_imprese'].mean().reset_index()


# Inserimento dei dati calcolati nel database

partecipazione_mercato_lavoro_aree.to_sql('partecipazione_mercato_lavoro_aree', conn, if_exists='replace', index=False)
partecipazione_mercato_lavoro_nazionale.to_sql('partecipazione_mercato_lavoro_nazionale', conn, if_exists='replace', index=False)
media_incidenza_spesa_ricerca_sviluppo_aree.to_sql('media_incidenza_spesa_ricerca_sviluppo_aree', conn, if_exists='replace', index=False)
media_tasso_sopravvivenza_imprese_nazionale.to_sql('media_tasso_sopravvivenza_imprese_nazionale', conn, if_exists='replace', index=False)
media_tasso_sopravvivenza_imprese_aree.to_sql('media_tasso_sopravvivenza_imprese_aree', conn, if_exists='replace', index=False)

conn.close()