from fastapi import FastAPI
from typing import Optional
import sqlite3
import pandas as pd

app = FastAPI()

def query_db(query: str, params: tuple = ()):
    conn = sqlite3.connect('imprese.db')
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df

@app.get("/mercato_lavoro_aree")
def get_partecipazione_totale_aree(da_anno: Optional[int] = None, a_anno: Optional[int] = None):
    query = "SELECT * FROM partecipazione_mercato_lavoro_aree"
    params = []
    if da_anno and a_anno:
        query += " WHERE anno BETWEEN ? AND ?"
        params.extend([da_anno, a_anno])
    df = query_db(query, tuple(params))
    return df.to_dict(orient='records')

@app.get("/mercato_lavoro_nazionale")
def get_partecipazione_totale_nazionale(da_anno: Optional[int] = None, a_anno: Optional[int] = None):
    query = "SELECT * FROM partecipazione_mercato_lavoro_nazionale"
    params = []
    if da_anno and a_anno:
        query += " WHERE anno BETWEEN ? AND ?"
        params.extend([da_anno, a_anno])
    df = query_db(query, tuple(params))
    return df.to_dict(orient='records')


#3. Media incidenza spesa imprese in ricerca sviluppo delle 5 Aree Nord-ovest, Nord-est, Centro, Sud, Isole
@app.get("/media_incidenza_spesa_ricerca_sviluppo_aree")
def get_media_incidenza_spesa_aree(da_anno: Optional[int] = None, a_anno: Optional[int] = None):
    query = "SELECT * FROM media_incidenza_spesa_ricerca_sviluppo_aree"
    params = []
    if da_anno and a_anno:
        query += " WHERE anno BETWEEN ? AND ?"
        params.extend([da_anno, a_anno])
    df = query_db(query, tuple(params))
    return df.to_dict(orient='records')

#4 Media tasso di sopravvivenza imprese alto tasso conoscenza NAZIONALE
@app.get("/media_tasso_sopravvivenza_imprese_nazionale")
def get_media_variazione_percentuale_occupazione_nazionale(da_anno: Optional[int] = None, a_anno: Optional[int] = None):
    query = "SELECT * FROM media_tasso_sopravvivenza_imprese_nazionale"
    params = []
    if da_anno and a_anno:
        query += " WHERE anno BETWEEN ? AND ?"
        params.extend([da_anno, a_anno])
    df = query_db(query, tuple(params))
    return df.to_dict(orient='records')

#5. Media tasso di sopravvivenza imprese alto tasso conoscenza delle 5 Aree Nord-ovest, Nord-est, Centro, Sud, Isole
@app.get("/media_tasso_sopravvivenza_imprese_aree")
def get_media_variazione_percentuale_occupazione_aree(da_anno: Optional[int] = None, a_anno: Optional[int] = None):
    query = "SELECT * FROM media_tasso_sopravvivenza_imprese_aree"
    params = []
    if da_anno and a_anno:
        query += " WHERE anno BETWEEN ? AND ?"
        params.extend([da_anno, a_anno])
    df = query_db(query, tuple(params))
    return df.to_dict(orient='records')