import matplotlib.pyplot as plt
import sqlite3
import pandas as pd

def plot_partecipazione_mercato_lavoro_nazionale():
    conn = sqlite3.connect('imprese.db')
    query = "SELECT * FROM partecipazione_mercato_lavoro_nazionale"
    df = pd.read_sql_query(query, conn)
    conn.close()

    plt.figure(figsize=(10, 6))
    plt.plot(df['anno'], df['partecipazione_mercato_lavoro'], marker='o')
    plt.title('Oartecipazione mercato lavoro')
    plt.xlabel('Anno')
    plt.ylabel('Partecipazione mercato lavoro')
    plt.grid(True)

    # Aggiungere tutti gli anni all'asse delle x
    plt.xticks(df['anno'])

    plt.savefig('partecipazione_mercato_lavoro_nazionale.png')

plot_partecipazione_mercato_lavoro_nazionale()