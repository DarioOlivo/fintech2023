import sqlite3

# Connessione al database
conn = sqlite3.connect('imprese.db')
cursor = conn.cursor()

# Creazione delle tabelle
cursor.execute('''
CREATE TABLE IF NOT EXISTS regioni (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    area_geografica TEXT
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS spesa_imprese (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    regione_id INTEGER,
    anno INTEGER,
    spesa_imprese FLOAT,
    FOREIGN KEY (regione_id) REFERENCES regioni(id)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS forza_lavoro (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    regione_id INTEGER,
    anno INTEGER,
    forza_lavoro FLOAT,
    FOREIGN KEY (regione_id) REFERENCES regioni(id)
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS sopravvivenza_imprese(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    regione_id INTEGER,
    anno INTEGER,
    sopravvivenza_imprese FLOAT,
    FOREIGN KEY (regione_id) REFERENCES regioni(id)
)
''')

# Inserimento delle regioni e aree geografiche
regioni = [
    ('Valle d\'Aosta', 'Nord-ovest'),
    ('Piemonte', 'Nord-ovest'),
    ('Liguria', 'Nord-ovest'),
    ('Lombardia', 'Nord-ovest'),
    ('Trentino-Alto Adige', 'Nord-est'),
    ('Veneto', 'Nord-est'),
    ('Friuli-Venezia Giulia', 'Nord-est'),
    ('Emilia-Romagna', 'Nord-est'),
    ('Toscana', 'Centro'),
    ('Umbria', 'Centro'),
    ('Marche', 'Centro'),
    ('Lazio', 'Centro'),
    ('Abruzzo', 'Centro'),
    ('Molise', 'Sud'),
    ('Campania', 'Sud'),
    ('Puglia', 'Sud'),
    ('Basilicata', 'Sud'),
    ('Calabria', 'Sud'),
    ('Sicilia', 'Isole'),
    ('Sardegna', 'Isole')
]

cursor.executemany('INSERT INTO regioni (nome, area_geografica) VALUES (?, ?)', regioni)

conn.commit()
conn.close()